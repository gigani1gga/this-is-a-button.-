package com.example.thisisabutton

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private val started = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val headline = findViewById<TextView>(R.id.headline)
        findViewById<Button>(R.id.button).setOnClickListener { button ->
            // Ignore repeat taps so the load is only started once.
            if (!started.compareAndSet(false, true)) return@setOnClickListener
            button.isEnabled = false
            headline.setText(R.string.overloading)
            // Give the UI a moment to draw before the app locks up.
            Handler(Looper.getMainLooper()).postDelayed({ overloadAndCrash() }, UI_SETTLE_MS)
        }
    }

    /** Overloads CPU + memory inside this app's own process, then crashes the app. */
    private fun overloadAndCrash() {
        // CPU: busy-loop threads, 4x the number of cores.
        repeat(Runtime.getRuntime().availableProcessors() * 4) {
            Thread {
                var x = 0.0
                while (true) x += Math.sqrt(x + 1.0) * Math.sin(x)
            }.apply { isDaemon = true }.start()
        }

        // Memory: allocate until this app's heap is exhausted, then crash on purpose.
        Thread {
            val hog = ArrayList<ByteArray>()
            try {
                while (true) hog.add(ByteArray(CHUNK_BYTES))
            } catch (_: OutOfMemoryError) {
                hog.clear()
                crash()
            }
        }.start()

        // Watchdog: guarantees the crash even if the heap is huge and OOM is slow.
        Thread {
            Thread.sleep(MAX_OVERLOAD_MS)
            crash()
        }.apply { isDaemon = true }.start()

        // UI thread: freeze the screen too.
        while (true) Math.random()
    }

    private fun crash(): Nothing =
        throw RuntimeException(getString(R.string.crash_message))

    private companion object {
        const val UI_SETTLE_MS = 300L
        const val MAX_OVERLOAD_MS = 8_000L
        const val CHUNK_BYTES = 10 * 1024 * 1024
    }
}
